#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>

void error(char *msg) // ΣΥΝΑΡΤΗΣΗ ΓΙΑ ΕΚΤΥΠΩΣΗ ΣΦΑΛΜΑΤΟΣ
{
    perror(msg);
    exit(0); //  0 ΓΙΑ ΤΟΝ ΠΕΛΑΤΗ (1 ΓΙΑ ΤΟΝ ΕΞΥΠΗΡΕΤΗ)
}

int main(int argc, char *argv[])
{
    int sd, portno;           // ΟΡΙΣΜΟΣ socket ΓΙΑ ΣΥΝΔΕΣΗ ΜΕ server, port number of the server
    struct sockaddr_in serv_addr; // ΟΡΙΣΜΟΣ Internet Address for Server
    struct hostent *server;       // ΔΟΜΗ ΠΟΥ ΑΠΟΘΗΚΕΥΟΝΤΑΙ ΟΙ ΠΛΗΡΟΦΟΡΙΕΣ 

    // ΜΕΤΑΒΛΗΤΕΣ ΠΟΥ ΑΡΧΙΚΟΠΟΙΟΥΝΤΑΙ ΑΠΟ ΧΡΗΣΤΗ
    float r;
    int n;
    float *Y;
    int choice;

    // ΜΕΤΑΒΛΗΤΕΣ ΑΠΟΤΕΛΕΣΜΑΤΩΝ
    float t, resAvg;
    float *resmin_max, *resMul;

    if (argc < 3) // ΕΑΝ ΤΑ ΟΡΙΣΜΑΤΑ ΔΕΝ ΔΟΘΟΥΝ ΑΡΚΕΤΑ: hostname, socket port
    {
        fprintf(stderr, "usage %s hostname port\n", argv[0]);
        exit(0);
    }

    portno = atoi(argv[2]);                   // ΑΡΧΙΚΟΠΟΙΗΣΗ ΘΥΡΑΣ ΒΑΣΗΣ ΟΡΙΣΜΑΤΟΣ
    sd = socket(AF_INET, SOCK_STREAM, 0); // ΔΗΜΙΟΥΡΓΙΑ socket ΓΙΑ ΕΠΙΚΟΙΝΩΝΙΑ  server-client 
    if (sd < 0)
        error("ERROR\n");

    server = gethostbyname(argv[1]); // ΑΡΧΙΚΟΠΟΙΗΣΗ ΠΛΗΡΟΦΟΡΙΩΝ
    if (server == NULL)
    {
        fprintf(stderr, "ERROR\n");
        exit(0);
    }

    // ΑΡΧΙΚΟΠΟΙΗΣΗ ΠΛΗΡΟΦΟΡΙΩΝ serv_addr ΠΟΥ ΕΙΝΑΙ ΔΟΜΗ sockaddr_in 
    bzero((char *)&serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(portno);
    bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);

    printf("Trying to connect...\n");

    // ΣΥΝΔΕΣΗ ΜΕ ΤΟ socket ΤΟΥ server - ΑΝΑΜΟΝΗ ΓΙΑ ΑΠΟΔΟΧΗ
    if (connect(sd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
        error("ERROR connecting");

    printf("Connected.\n");

    do
    {
        // printing Menu
        printf("1. Calculate Average\n");
        printf("2. Calculate Min_Max\n");
        printf("3. Calculate the Product: r*(Y)\n");
        printf("4. Exit\n\n");

        // ΕΠΙΛΟΦΗ
        scanf("%d", &choice);

        if (choice != 1 && choice != 2 && choice != 3 && choice != 4) 
        {
            printf("try again !\n");
            continue; 
        }

        // ΣΤΕΛΝΕΙ ΕΠΙΛΟΓΗ ΣΤΟ socket_server/ rpc_client
        send(sd, &choice, sizeof(choice), 0);

        if (choice == 4) 
        {
            printf("Exiting...\n");
            close(sd);
            exit(0);
        }

        // ΔΙΑΒΑΣΜΑ r
        printf("Enter float number (r): ");
        scanf("%f", &r);              
        send(sd, &r, sizeof(r), 0); // ΑΠΟΣΤΟΛΗ r ΣΤΟ socket_server/ rpc_client

        // n
        printf("Enter length of array (n): ");
        scanf("%d", &n);                // DIABASMA n
        send(sd, &n, sizeof(n), 0); // ΑΠΟΣΤΟΛΗ n ΣΤΟ socket_server/ rpc_client

      
        Y = (float *)malloc(n * sizeof(float));
        if (Y == NULL)
            error("ERROR Memory\n");

        // Y
        printf("Enter %d Y array:\n", n);
        for (int i = 0; i < n; i++)
            scanf("%f", &Y[i]);              // ΔΙΑΒΑΣΜΑ Y values
        send(sd, Y, n * sizeof(float), 0); // ΑΠΟΣΤΟΛΗ ΤΟΥ Y ΣΤΟ socket_server/ rpc_client

        printf("\n");

        // ΛΗΨΗ ΚΑΙ ΕΚΤΥΠΩΣΗ ΑΠΟΤΕΛΕΣΜΑΤΩΝ
        printf("Results:\n");
        if (choice == 1)
        {
            t = recv(sd, &resAvg, sizeof(resAvg), 0);
            printf("Avarage = %f\n", resAvg);
        }
        else if (choice == 2)
        {
            resmin_max= (float *)malloc(2 * sizeof(float));
            t = recv(sd, resmin_max, 2 * sizeof(float), 0);
            printf("min= %f, max= %f\n", resmin_max[0], resmin_max[1]);
        }
        else if (choice == 3)
        {
            resMul = (float *)malloc(n * sizeof(float));
            t = recv(sd, resMul, n * sizeof(float), 0);
            printf("Product r*(Y):\n");
            for (int i = 0; i < n; i++)
                printf("arr[%d]= %f\n", i, resMul[i]);
        }

        if (t < 1) // ΕΑΝ Η ΛΗΨΗ ΔΕΔΟΜΕΝΩΝ ΑΠΟΤΥΧΕΙ ΤΟΤΕ ΤΟ loop ΣΤΑΜΑΤΑ
            break;
    } while (choice != 4); 

    // ΑΠΕΛΕΥΘΕΡΩΣΗ ΜΝΗΜΗΣ
    free(Y);

    close(sd); // close server-client's socket

    return 0;
}
